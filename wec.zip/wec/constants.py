# wec/constants.py

SECONDS_PER_MONTH = 30.5 * 24 * 3600  # среднее число секунд в месяце
